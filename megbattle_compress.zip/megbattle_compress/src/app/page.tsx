'use client';
import Image from 'next/image';
import Layout from './components/Layout';
import { usePathname } from 'next/navigation';
import { useEffect, useState } from 'react';
import Header from './components/Header';
import highVoltage from '../../public/images/high-voltage.png';
import { telegramClient } from './provider/telegram-provider';
import { useUserStore } from './store/useUserStore';
import { getPoint, setPoint } from './hooks/useLocalStorage';
import { RotatingLines } from 'react-loader-spinner';

export default function Home() {
  const { user, webApp } = telegramClient();
  const pathname = usePathname();
  const [mobile, setMobile] = useState<any>();
  const [energy, setEnergy] = useState(1000);
  const [clicks, setClicks] = useState<{ id: number; x: number; y: number }[]>(
    []
  );
  const [imgSrc, setImgSrc] = useState<any>();
  const [points, setPoints] = useState(0);

  const setUser = useUserStore((state) => state.setUser);
  const userData = useUserStore((state) => state.user);
  const pointsToAdd = 1;
  const energyToReduce = 1;

  useEffect(() => {
    if (points < 5000) {
      setImgSrc('/images/1.png');
    } else if (points >= 5000 && points < 25000) {
      setImgSrc('/images/2.png');
    } else if (points >= 25000 && points < 100000) {
      setImgSrc('/images/3.png');
    } else if (points >= 100000 && points < 1000000) {
      setImgSrc('/images/4.png');
    } else if (points >= 1000000 && points < 2000000) {
      setImgSrc('/images/5.png');
    } else if (points >= 2000000 && points < 10000000) {
      setImgSrc('/images/6.png');
    } else if (points >= 10000000 && points < 100000000) {
      setImgSrc('/images/7.png');
    } else if (points >= 100000000 && points < 500000000) {
      setImgSrc('/images/8.png');
    } else if (points >= 500000000 && points < 1000000000) {
      setImgSrc('/images/9.png');
    }
  }, [points]);

  useEffect(() => {
    if (user) {
      const storedPoints = getPoint(`${user.id}`);
      setPoints(storedPoints);
    }
  }, [user]);

  useEffect(() => {
    const interval = setInterval(() => {
      setEnergy((prevEnergy) => Math.min(prevEnergy + 1, 1000));
    }, 10000);

    return () => clearInterval(interval);
  }, []);

  const handleClick = (e: React.MouseEvent<HTMLDivElement, MouseEvent>) => {
    if (energy - energyToReduce < 0) {
      return;
    }
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const newPoints = points + pointsToAdd;
    setPoints(newPoints);
    setPoint(`${user?.id}`, newPoints);
    setEnergy(energy - energyToReduce < 0 ? 0 : energy - energyToReduce);
    setClicks([...clicks, { id: Date.now(), x, y }]);
  };

  const handleAnimationEnd = (id: number) => {
    setClicks((prevClicks) => prevClicks.filter((click) => click.id !== id));
  };

  if (!user) {
    return (
      <Layout energy={energy}>
        <div className="flex-grow flex items-center justify-center">
          <RotatingLines
            strokeColor="#000000"
            strokeWidth="5"
            animationDuration="0.75"
            width="24"
            visible
          />
        </div>
      </Layout>
    );
  }

  return (
    <Layout energy={energy}>
      {pathname === '/' && <Header points={points} name={user?.first_name} />}
      {pathname === '/' && (
        <div className="flex-grow mt-28 flex flex-col items-center justify-center">
          <div className="relative mt-4 cursor-pointer" onClick={handleClick}>
            <Image
              src={imgSrc}
              width={256}
              height={256}
              alt="Monkey"
              className="drop-shadow-2xl"
            />
            {clicks.map((click) => (
              <div
                key={click.id}
                className="absolute text-5xl font-bold opacity-0 float cursor-pointer"
                style={{
                  top: `${click.y - 42}px`,
                  left: `${click.x - 28}px`,
                }}
                onAnimationEnd={() => handleAnimationEnd(click.id)}
              >
                +1
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="flex pl-4 mb-28 w-full justify-start items-center">
        <Image src={highVoltage} width={44} height={44} alt="High Voltage" />
        <div className="ml-2 text-left">
          <span className="text-white text-2xl font-bold block">{energy}</span>
          <span className="text-white text-large opacity-75">/ 1000</span>
        </div>
      </div>
    </Layout>
  );
}
