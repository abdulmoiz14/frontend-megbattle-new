import { useState, useEffect } from 'react';
import Image from 'next/image';
import coin from '../../../public/images/coin.png';

const Header = ({ points, name }: { points: number; name?: string }) => {
  const [currentPoints, setCurrentPoints] = useState(points);
  const [barWidth, setBarWidth] = useState(0);
  const barIncrement = 1;
  const [level, setLevel] = useState<number>(1);

  useEffect(() => {
    const newBarWidth = (currentPoints % 100) * barIncrement;
    setBarWidth(newBarWidth);
    setCurrentPoints(points);
  }, [points, currentPoints, barIncrement]);

  useEffect(() => {
    if (points < 5000) {
      setLevel(1);
    } else if (points >= 5000 && points < 25000) {
      setLevel(2);
    } else if (points >= 25000 && points < 100000) {
      setLevel(3);
    } else if (points >= 100000 && points < 1000000) {
      setLevel(4);
    } else if (points >= 1000000 && points < 2000000) {
      setLevel(5);
    } else if (points >= 2000000 && points < 10000000) {
      setLevel(6);
    } else if (points >= 10000000 && points < 100000000) {
      setLevel(7);
    } else if (points >= 100000000 && points < 500000000) {
      setLevel(8);
    } else if (points >= 500000000 && points < 1000000000) {
      setLevel(9);
    }
  }, [points]);

  return (
    <div className="fixed top-0 left-0 w-full px-4 z-10 flex flex-col items-center text-white">
      <h1 className="text-2xl font-bold mb-2 text-center ">Hello {name}</h1>
      <div className="mt-6 mb-3 text-5xl font-bold flex items-center">
        <Image src={coin} width={44} height={44} alt="Coin" />
        <span className="ml-2">{currentPoints.toLocaleString()}</span>
      </div>
      <div className="w-full bg-[#333] rounded-full mt-2">
        <div
          className="bg-gradient-to-r from-[#0d9de8] to-[#ff00ec] h-2 rounded-full transition-all duration-500"
          style={{ width: `${Math.min(barWidth, 100)}%` }}
        ></div>
      </div>
      <div className="flex w-full mt-4">Level {level}/9</div>
    </div>
  );
};

export default Header;
