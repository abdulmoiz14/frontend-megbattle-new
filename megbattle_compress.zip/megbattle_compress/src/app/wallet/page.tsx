import Layout from '../components/Layout';

const Wallet = () => {
  return (
    <Layout>
      <div className="fixed top-0 left-0 w-screen h-screen bg-black bg-opacity-70 flex items-center justify-center z-10 pointer-events-none">
        <div>
          <h2 className="text-4xl font-bold mb-4">Coming Soon</h2>
          <p className="text-gray-600">
            This feature is currently under development and will be available
            soon.
          </p>
        </div>
      </div>
    </Layout>
  );
};

export default Wallet;
