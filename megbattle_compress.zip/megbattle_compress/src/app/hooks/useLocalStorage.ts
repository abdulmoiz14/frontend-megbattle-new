export const setPoint = (key: string, value: number) => {
  if (typeof window !== 'undefined') {
    localStorage.setItem(key, value.toString());
  }
};

export const getPoint = (key: string) => {
  if (typeof window !== 'undefined') {
    const storedValue = localStorage.getItem(key);
    return storedValue ? parseInt(storedValue) : 0;
  }
  return 0;
};
