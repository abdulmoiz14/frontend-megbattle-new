import dragon from './dragon.png';
import coin from './coin.png';
import highVoltage from './high-voltage.png';
import tap from './tap.png';
import friends from './friends.png';
import earn from './earn.png';
import wallet from './wallet.png';

export {
  dragon,
  coin,
  highVoltage,
  tap,
  friends,
  earn,
  wallet,
};
